package com.example.laptop_harbor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
