import 'package:flutter/material.dart';

enum OrderStatus {
  pending,
  processing,
  shipped,
  delivered,
  cancelled,
}

extension OrderStatusExtension on OrderStatus {
  String get label {
    switch (this) {
      case OrderStatus.pending:
        return "Pending";
      case OrderStatus.processing:
        return "Processing";
      case OrderStatus.shipped:
        return "Shipped";
      case OrderStatus.delivered:
        return "Delivered";
      case OrderStatus.cancelled:
        return "Cancelled";
    }
  }

  Color get color {
    switch (this) {
      case OrderStatus.pending:
        return Colors.orange.withValues(alpha: 0.9);
      case OrderStatus.processing:
        return Colors.blue.withValues(alpha: 0.9);
      case OrderStatus.shipped:
        return Colors.purple.withValues(alpha: 0.9);
      case OrderStatus.delivered:
        return Colors.green.withValues(alpha: 0.9);
      case OrderStatus.cancelled:
        return Colors.red.withValues(alpha: 0.9);
    }
  }

  IconData get icon {
    switch (this) {
      case OrderStatus.pending:
        return Icons.pending;
      case OrderStatus.processing:
        return Icons.refresh;
      case OrderStatus.shipped:
        return Icons.local_shipping;
      case OrderStatus.delivered:
        return Icons.check_circle;
      case OrderStatus.cancelled:
        return Icons.cancel;
    }
  }
}
