class Product {
  final String id;
  final String name;
  final String brand;
  final String category;
  final double price;
  final double rating;
  final String imageUrl;
  final String description;
  final List<String> specifications; // Now follows masterSpecTitles
  final List<Review> reviews;

  Product({
    required this.id,
    required this.name,
    required this.brand,
    required this.category,
    required this.price,
    required this.rating,
    required this.imageUrl,
    required this.description,
    required this.specifications,
    required this.reviews,
  });

  static List<Product> get dummyProducts => [
        Product(
          id: '1',
          name: 'MacBook Pro M3 Max',
          brand: 'Apple',
          category: 'Creative',
          price: 3499.99,
          rating: 4.9,
          imageUrl:
              'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1000&auto=format&fit=crop',
          description:
              'The most powerful MacBook ever. With the M3 Max chip, it delivers extreme performance for the most demanding workflows.',
          specifications: [
            'RAM: 64GB',
            'Storage: 1TB SSD',
            'Battery: 12 hours',
            'Processor: Apple M3 Max 16-core CPU',
            'Graphics: 40-core GPU',
            'Display: 16.2" Liquid Retina XDR',
            'Weight: 2.2 kg',
            'OS: macOS Sonoma'
          ],
          reviews: [
            Review(
                userId: 'u1',
                userName: 'Alice',
                rating: 5.0,
                comment: 'Absolute beast for video editing!',
                date: DateTime.now()),
          ],
        ),
        Product(
          id: '2',
          name: 'Dell XPS 17 9730',
          brand: 'Dell',
          category: 'Business',
          price: 2599.99,
          rating: 4.8,
          imageUrl:
              'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?q=80&w=1000&auto=format&fit=crop',
          description:
              'Experience power and beauty on a grand scale with the XPS 17, featuring a stunning 4K+ display.',
          specifications: [
            'RAM: 32GB',
            'Storage: 1TB SSD',
            'Battery: 10 hours',
            'Processor: Intel Core i9-13900H',
            'Graphics: NVIDIA RTX 4070 8GB',
            'Display: 17" UHD+ InfinityEdge Touch',
            'Weight: 2.5 kg',
            'OS: Windows 11 Pro'
          ],
          reviews: [],
        ),
        Product(
          id: '3',
          name: 'HP Spectre x360 14',
          brand: 'HP',
          category: 'Student',
          price: 1499.99,
          rating: 4.7,
          imageUrl:
              'https://images.unsplash.com/photo-1544006659-f0b21f04cb1d?q=80&w=1000&auto=format&fit=crop',
          description:
              'The HP Spectre x360 2-in-1 laptop automatically adapts to your surroundings for the best on-screen image.',
          specifications: [
            'RAM: 16GB',
            'Storage: 512GB SSD',
            'Battery: 9 hours',
            'Processor: Intel Core i7-1355U',
            'Graphics: Intel Iris Xe',
            'Display: 13.5" 3K2K OLED Touch',
            'Weight: 1.3 kg',
            'OS: Windows 11 Home'
          ],
          reviews: [],
        ),
        Product(
          id: '4',
          name: 'Razer Blade 18',
          brand: 'Razer',
          category: 'Gaming',
          price: 4499.99,
          rating: 4.9,
          imageUrl:
              'https://images.unsplash.com/photo-1525547718571-a7144c1ff391?q=80&w=1000&auto=format&fit=crop',
          description:
              'The ultimate desktop replacement. The Razer Blade 18 combines desktop-grade performance with a sleek laptop design.',
          specifications: [
            'RAM: 64GB',
            'Storage: 4TB SSD',
            'Battery: 8 hours',
            'Processor: Intel Core i9-13980HX',
            'Graphics: NVIDIA RTX 4090 16GB',
            'Display: 18" QHD+ 240Hz',
            'Weight: 2.9 kg',
            'OS: Windows 11 Pro'
          ],
          reviews: [],
        ),
        Product(
          id: '5',
          name: 'ASUS ROG Zephyrus M16',
          brand: 'ASUS',
          category: 'Gaming',
          price: 1999.99,
          rating: 4.8,
          imageUrl:
              'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?q=80&w=1000&auto=format&fit=crop',
          description:
              'Fast, sleek, and ultra-slim, the Zephyrus M16 delivers an exhilarating Windows 11 Pro experience.',
          specifications: [
            'RAM: 16GB',
            'Storage: 1TB SSD',
            'Battery: 9 hours',
            'Processor: Intel Core i9-13900H',
            'Graphics: NVIDIA RTX 4070',
            'Display: 16" QHD+ 240Hz',
            'Weight: 2.1 kg',
            'OS: Windows 11 Pro'
          ],
          reviews: [],
        ),
        Product(
          id: '6',
          name: 'Lenovo ThinkPad X1 Carbon Gen 11',
          brand: 'Lenovo',
          category: 'Business',
          price: 1899.99,
          rating: 4.7,
          imageUrl:
              'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?q=80&w=1000&auto=format&fit=crop',
          description:
              'The ultimate professional laptop, featuring a lightweight carbon-fiber chassis and legendary durability.',
          specifications: [
            'RAM: 32GB',
            'Storage: 1TB SSD',
            'Battery: 11 hours',
            'Processor: Intel Core i7-1365U',
            'Graphics: Intel Iris Xe',
            'Display: 14" 2.8K OLED',
            'Weight: 1.1 kg',
            'OS: Windows 11 Pro'
          ],
          reviews: [],
        ),
      ];
}

class Review {
  final String userId;
  final String userName;
  final double rating;
  final String comment;
  final DateTime date;

  Review({
    required this.userId,
    required this.userName,
    required this.rating,
    required this.comment,
    required this.date,
  });
}
