class ShippingAddress {
  String label;
  String address;

  ShippingAddress({required this.label, required this.address});
}