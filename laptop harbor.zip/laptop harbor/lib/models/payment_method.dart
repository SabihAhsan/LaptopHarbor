class PaymentMethod {
  String type; // e.g., Visa, PayPal
  String details; // e.g., "**** 1234" or email
  String? expiry; // optional for cards

  PaymentMethod({required this.type, required this.details, this.expiry});
}
