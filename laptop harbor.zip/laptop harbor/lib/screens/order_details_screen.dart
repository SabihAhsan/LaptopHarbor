import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/order_provider.dart';
import '../models/order.dart';
import '../models/order_status.dart';

/// ================= ORDER DETAILS SCREEN =================
class OrderDetailsScreen extends StatelessWidget {
  final String orderId;

  const OrderDetailsScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    final orderProvider = context.watch<OrderProvider>();
    final order = orderProvider.getOrderById(orderId);

    if (order == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Order Details')),
        body: const Center(child: Text("❌ Order not found")),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Order #${order.id}"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          //---------------- STATUS CARD ----------------//
          _statusCard(order),

          const SizedBox(height: 20),

          //---------------- ORDER ITEMS ----------------//
          _sectionTitle("Items"),
          const SizedBox(height: 10),
          ...order.items.map((item) => _buildOrderItem(item, context)),

          const SizedBox(height: 24),

          //---------------- SHIPPING ADDRESS ----------------//
          _sectionTitle("Shipping Address"),
          const SizedBox(height: 8),
          Text(order.shippingAddress, style: const TextStyle(fontSize: 16)),

          const SizedBox(height: 24),

          //---------------- PAYMENT METHOD ----------------//
          _sectionTitle("Payment Method"),
          const SizedBox(height: 8),
          Text(order.paymentMethod, style: const TextStyle(fontSize: 16)),

          const SizedBox(height: 24),

          //---------------- ORDER DATE ----------------//
          _sectionTitle("Order Date"),
          const SizedBox(height: 8),
          Text(
            "${order.orderDate.day}/${order.orderDate.month}/${order.orderDate.year}",
            style: const TextStyle(fontSize: 16),
          ),

          const SizedBox(height: 28),

          //---------------- TOTAL AMOUNT CARD ----------------//
          _totalAmountCard(order.totalAmount),

          const SizedBox(height: 35),

          //---------------- ACTION BUTTON ----------------//
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                // Future: reorder / track order
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                backgroundColor: AppTheme.primaryColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                "Reorder Items",
                style: TextStyle(fontSize: 16),
              ),
            ),
          ),

          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  //---------------- WIDGETS ----------------//

  /// STATUS CARD
  Widget _statusCard(Order order) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: order.status.color.withOpacity(.12),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        Icon(
          order.status.icon,
          color: order.status.color,
          size: 28,
        ),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            "Order Status",
            style: TextStyle(
              color: order.status.color,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            order.status.label,
            style: TextStyle(
              color: order.status.color,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ]),
      ]),
    );
  }

  /// ORDER ITEM CARD
  Widget _buildOrderItem(OrderItem item, BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            blurRadius: 6,
            offset: const Offset(0, 2),
            color: Colors.black.withOpacity(.05),
          ),
        ],
      ),
      child: Row(children: [

        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(
            item.productImage,
            width: 60,
            height: 60,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              width: 60,
              height: 60,
              color: AppTheme.primaryColor.withOpacity(.1),
              child: const Icon(Icons.image_not_supported),
            ),
          ),
        ),

        const SizedBox(width: 12),

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.productName,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                "Qty: ${item.quantity}",
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),

        Text(
          "Rs ${item.totalPrice.toStringAsFixed(0)}",
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
        ),
      ]),
    );
  }

  /// SECTION TITLE
  Widget _sectionTitle(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 18,
        letterSpacing: .3,
      ),
    );
  }

  /// TOTAL AMOUNT CARD
  Widget _totalAmountCard(double total) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(.07),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            "Total Amount",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            "Rs ${total.toStringAsFixed(0)}",
            style: TextStyle(
              fontSize: 24,
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
