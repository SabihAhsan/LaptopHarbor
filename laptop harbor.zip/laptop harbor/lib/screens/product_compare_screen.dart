import 'package:flutter/material.dart';
import '../models/product.dart';
import 'product_details_screen.dart'; // For access to masterSpecTitles

class ProductCompareScreen extends StatelessWidget {
  final Product product1;
  final Product product2;

  const ProductCompareScreen({
    super.key,
    required this.product1,
    required this.product2,
  });

  // Master spec titles for consistency
  static const List<String> masterSpecTitles = ProductDetailsScreen.masterSpecTitles;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Compare Products"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                _buildProductCard(product1, theme, isDark),
                const SizedBox(width: 16),
                _buildProductCard(product2, theme, isDark),
              ],
            ),
            const SizedBox(height: 24),
            _buildComparisonTable(theme),
          ],
        ),
      ),
    );
  }

  Widget _buildProductCard(Product product, ThemeData theme, bool isDark) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.network(
            product.imageUrl,
            height: 150,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => Container(
              height: 150,
              color: theme.primaryColor.withOpacity(0.1),
              child: const Icon(Icons.laptop_mac_rounded, size: 60),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            product.name,
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '\$${product.price.toStringAsFixed(2)}',
            style: theme.textTheme.titleMedium?.copyWith(
              color: theme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.star, color: Colors.amber, size: 18),
              const SizedBox(width: 4),
              Text(
                product.rating.toString(),
                style: theme.textTheme.bodyMedium,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildComparisonTable(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Specifications Comparison',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Table(
          border: TableBorder.all(color: theme.primaryColor.withOpacity(0.2)),
          columnWidths: const {
            0: FlexColumnWidth(2),
            1: FlexColumnWidth(2),
            2: FlexColumnWidth(2),
          },
          children: [
            TableRow(
              decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1)),
              children: const [
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text('Specification', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text('Product 1', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text('Product 2', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            ...masterSpecTitles.map((title) {
              // Fetch specs from each product
              final value1 = product1.specifications
                      .firstWhere(
                        (s) => s.toLowerCase().startsWith(title.toLowerCase()),
                        orElse: () => '-',
                      )
                      .split(':')
                      .skip(1)
                      .join(':')
                      .trim();
              final value2 = product2.specifications
                      .firstWhere(
                        (s) => s.toLowerCase().startsWith(title.toLowerCase()),
                        orElse: () => '-',
                      )
                      .split(':')
                      .skip(1)
                      .join(':')
                      .trim();

              return TableRow(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(value1.isEmpty ? '-' : value1),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(value2.isEmpty ? '-' : value2),
                  ),
                ],
              );
            }).toList(),
          ],
        ),
      ],
    );
  }
}
