import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/cart_provider.dart';
import '../providers/order_provider.dart';
import 'order_confirmation_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  // ================= STATE =================
  String selectedPayment = 'Credit Card';
  String addressTitle = 'Home';
  String addressDetails = '123 Street, City, Country';

  final List<String> paymentMethods = [
    'Credit Card',
    'PayPal',
    'Cash on Delivery',
  ];

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: AppTheme.scaffoldColor,
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'Checkout',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionTitle('Shipping Address'),
            _addressCard(),
            const SizedBox(height: 28),

            _sectionTitle('Payment Method'),
            ...paymentMethods.map(
              (method) => _paymentOption(method),
            ),
            const SizedBox(height: 28),

            _sectionTitle('Order Summary'),
            _summaryCard(cart),
            const SizedBox(height: 40),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: cart.items.isEmpty
                    ? null
                    : () {
                        _placeOrder(context, cart);
                      },
                child: const Text(
                  'Place Order',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================= PLACE ORDER =================
  void _placeOrder(BuildContext context, CartProvider cart) {
    final orderProvider = context.read<OrderProvider>();
    final shippingAddress = '$addressTitle - $addressDetails';

    // Add order from cart
    orderProvider.addOrderFromCart(cart, shippingAddress, selectedPayment);

    // Clear cart after order placement
    cart.clearCart();

    // Navigate to confirmation
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const OrderConfirmationScreen(),
      ),
    );
  }

  // ================= SECTION TITLE =================
  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .titleMedium
            ?.copyWith(fontWeight: FontWeight.bold),
      ),
    );
  }

  // ================= ADDRESS CARD =================
  Widget _addressCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardDecoration(),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
            child: const Icon(
              Icons.location_on,
              color: AppTheme.primaryColor,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  addressTitle,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  addressDetails,
                  style: const TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: _changeAddress,
            child: const Text('Change'),
          ),
        ],
      ),
    );
  }

  // ================= CHANGE ADDRESS =================
  void _changeAddress() {
    final titleController = TextEditingController(text: addressTitle);
    final addressController =
        TextEditingController(text: addressDetails);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        return Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            20,
            20,
            MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Update Address',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Label'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: addressController,
                decoration:
                    const InputDecoration(labelText: 'Full Address'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    addressTitle = titleController.text;
                    addressDetails = addressController.text;
                  });
                  Navigator.pop(context);
                },
                child: const Text('Save Address'),
              ),
            ],
          ),
        );
      },
    );
  }

  // ================= PAYMENT OPTION =================
  Widget _paymentOption(String method) {
    final isSelected = selectedPayment == method;

    IconData icon;
    if (method == 'Credit Card') {
      icon = Icons.credit_card;
    } else if (method == 'PayPal') {
      icon = Icons.account_balance_wallet;
    } else {
      icon = Icons.money;
    }

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedPayment = method;
        });
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color:
              isSelected ? AppTheme.primaryColor.withOpacity(0.08) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color:
                isSelected ? AppTheme.primaryColor : Colors.grey.shade300,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color:
                  isSelected ? AppTheme.primaryColor : Colors.grey,
            ),
            const SizedBox(width: 16),
            Text(
              method,
              style: TextStyle(
                fontWeight:
                    isSelected ? FontWeight.bold : FontWeight.w500,
              ),
            ),
            const Spacer(),
            if (isSelected)
              const Icon(
                Icons.check_circle,
                color: AppTheme.primaryColor,
              ),
          ],
        ),
      ),
    );
  }

  // ================= SUMMARY CARD =================
  Widget _summaryCard(CartProvider cart) {
    final double tax = 120.0; // You can make this dynamic later
    final double total = cart.subtotal + tax;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _cardDecoration(),
      child: Column(
        children: [
          _summaryRow('Items (${cart.totalItems})',
              '\$${cart.subtotal.toStringAsFixed(2)}', false),
          _summaryRow('Shipping', 'Free', false),
          _summaryRow('Tax', '\$${tax.toStringAsFixed(2)}', false),
          const Divider(height: 28),
          _summaryRow('Total', '\$${total.toStringAsFixed(2)}', true),
        ],
      ),
    );
  }

  Widget _summaryRow(String label, String value, bool isTotal) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: isTotal ? 18 : 14,
              fontWeight:
                  isTotal ? FontWeight.bold : FontWeight.w500,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: isTotal ? 18 : 14,
              fontWeight:
                  isTotal ? FontWeight.bold : FontWeight.w600,
              color:
                  isTotal ? AppTheme.primaryColor : AppTheme.textColor,
            ),
          ),
        ],
      ),
    );
  }

  // ================= COMMON CARD STYLE =================
  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.06),
          blurRadius: 12,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }
}
