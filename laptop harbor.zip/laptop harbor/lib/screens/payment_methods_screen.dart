import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/payment_provider.dart';
import '../models/payment_method.dart';

class PaymentMethodsScreen extends StatelessWidget {
  const PaymentMethodsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Payment Methods',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Consumer<PaymentProvider>(
        builder: (context, provider, _) {
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: provider.methods.length,
            itemBuilder: (context, index) {
              final method = provider.methods[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: Icon(method.type.toLowerCase() == 'visa'
                      ? Icons.credit_card
                      : Icons.account_balance_wallet),
                  title: Text(
                    method.type == 'Visa'
                        ? '${method.type} ${method.details}'
                        : method.type,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(method.expiry ?? method.details),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    onPressed: () => provider.removeMethod(index),
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddMethodDialog(context);
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddMethodDialog(BuildContext context) {
    final typeController = TextEditingController();
    final detailsController = TextEditingController();
    final expiryController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Payment Method'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: typeController,
              decoration: const InputDecoration(labelText: 'Type (Visa/PayPal)'),
            ),
            TextField(
              controller: detailsController,
              decoration: const InputDecoration(labelText: 'Details'),
            ),
            TextField(
              controller: expiryController,
              decoration: const InputDecoration(labelText: 'Expiry (if any)'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final newMethod = PaymentMethod(
                type: typeController.text,
                details: detailsController.text,
                expiry: expiryController.text.isEmpty
                    ? null
                    : expiryController.text,
              );
              Provider.of<PaymentProvider>(context, listen: false)
                  .addMethod(newMethod);
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}
