import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../providers/wishlist_provider.dart';
import 'product_details_screen.dart';

class WishlistScreen extends StatelessWidget {
  const WishlistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Wishlist'),
        automaticallyImplyLeading: false,
      ),
      body: Consumer<WishlistProvider>(
        builder: (context, wishlistProvider, _) {
          final wishlistProducts = wishlistProvider.items;

          if (wishlistProducts.isEmpty) {
            return _buildEmptyWishlist(theme);
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: wishlistProducts.length,
            itemBuilder: (context, index) {
              return _wishlistItem(
                context,
                wishlistProducts[index],
                theme,
                isDark,
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildEmptyWishlist(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.favorite_border_rounded,
            size: 80,
            color: theme.primaryColor.withAlpha(50), // fixed deprecated withOpacity
          ),
          const SizedBox(height: 20),
          const Text(
            'Your wishlist is empty',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            'Save your favorite laptops here!',
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _wishlistItem(
      BuildContext context, Product product, ThemeData theme, bool isDark) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ProductDetailsScreen(product: product),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.cardTheme.color,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(isDark ? 77 : 13), // fixed deprecated withOpacity
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.network(
                product.imageUrl,
                width: 80,
                height: 80,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  width: 80,
                  height: 80,
                  color: theme.primaryColor.withAlpha(25), // fixed deprecated withOpacity
                  child: Icon(Icons.laptop_mac_rounded, color: theme.primaryColor),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '\$${product.price.toStringAsFixed(2)}',
                    style: TextStyle(
                        color: theme.primaryColor, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Consumer<WishlistProvider>(
                  builder: (context, wishlistProvider, _) {
                    final isInWishlist = wishlistProvider.isInWishlist(product);
                    return IconButton(
                      icon: Icon(
                        isInWishlist ? Icons.favorite : Icons.favorite_border,
                        color: isInWishlist ? Colors.red : theme.primaryColor,
                      ),
                      onPressed: () {
                        wishlistProvider.toggleWishlist(product);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(isInWishlist
                                ? '${product.name} removed from wishlist'
                                : '${product.name} added to wishlist'),
                            backgroundColor: theme.primaryColor,
                          ),
                        );
                      },
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.add_shopping_cart_rounded,
                      color: theme.primaryColor),
                  onPressed: () {
                    context.read<CartProvider>().addToCart(product);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content:
                              Text('${product.name} added to cart'),
                          backgroundColor: theme.primaryColor),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
