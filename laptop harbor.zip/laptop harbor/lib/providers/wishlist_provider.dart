import 'package:flutter/material.dart';
import '../models/product.dart'; // make sure you have this model

class WishlistProvider with ChangeNotifier {
  final List<Product> _items = [];

  List<Product> get items => _items;

  void toggleWishlist(Product product) {
    if (_items.contains(product)) {
      _items.remove(product);
    } else {
      _items.add(product);
    }
    notifyListeners();
  }

  bool isInWishlist(Product product) {
    return _items.contains(product);
  }
}
