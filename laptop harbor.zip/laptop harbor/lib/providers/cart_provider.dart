import 'package:flutter/foundation.dart';
import '../models/product.dart';

/// ================= CART ITEM =================
class CartItem {
  final Product product;
  int quantity;

  CartItem({
    required this.product,
    this.quantity = 1,
  });

  double get totalPrice => product.price * quantity;
}

/// ================= CART PROVIDER =================
class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => List.unmodifiable(_items);

  /// Total quantity of all items
  int get totalItems =>
      _items.fold(0, (sum, item) => sum + item.quantity);

  /// Subtotal price
  double get subtotal =>
      _items.fold(0, (sum, item) => sum + item.totalPrice);

  /// ================= ADD TO CART =================
  void addToCart(Product product) {
    final index =
        _items.indexWhere((item) => item.product.id == product.id);

    if (index != -1) {
      _items[index].quantity++;
    } else {
      _items.add(CartItem(product: product));
    }
    notifyListeners();
  }

  /// ================= REMOVE ITEM COMPLETELY =================
  void removeFromCart(String productId) {
    _items.removeWhere((item) => item.product.id == productId);
    notifyListeners();
  }

  /// ================= INCREASE QUANTITY =================
  void increaseQty(CartItem item) {
    item.quantity++;
    notifyListeners();
  }

  /// ================= DECREASE QUANTITY =================
  void decreaseQty(CartItem item) {
    if (item.quantity > 1) {
      item.quantity--;
    } else {
      _items.remove(item);
    }
    notifyListeners();
  }

  /// ================= CLEAR CART =================
  void clearCart() {
    _items.clear();
    notifyListeners();
  }

  /// ================= CHECK IF PRODUCT EXISTS =================
  bool isInCart(String productId) {
    return _items.any((item) => item.product.id == productId);
  }
}
