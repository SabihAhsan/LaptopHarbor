import 'package:flutter/material.dart';
import '../models/shipping_address.dart';

class ShippingAddressProvider with ChangeNotifier {
  final List<ShippingAddress> _addresses = [
    ShippingAddress(label: 'Home', address: '123 Laptop Street, Tech City, 56789'),
    ShippingAddress(label: 'Office', address: '456 Tech Avenue, Tech City, 56789'),
  ];

  List<ShippingAddress> get addresses => _addresses;

  void addAddress(ShippingAddress address) {
    _addresses.add(address);
    notifyListeners();
  }

  void updateAddress(int index, ShippingAddress address) {
    _addresses[index] = address;
    notifyListeners();
  }

  void removeAddress(int index) {
    _addresses.removeAt(index);
    notifyListeners();
  }
}
