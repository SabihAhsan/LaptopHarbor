import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import '../models/user.dart';

class AuthProvider with ChangeNotifier {
  final fb.FirebaseAuth _auth = fb.FirebaseAuth.instance;
  User? _user;

  User? get user => _user;
  bool get isAuthenticated => _user != null;

  AuthProvider() {
    // Initialize current user if already logged in
    final fbUser = _auth.currentUser;
    if (fbUser != null) {
      _user = _firebaseUserToUser(fbUser);
    }
  }

  // Helper: convert Firebase user to your local User model
  User _firebaseUserToUser(fb.User fbUser) {
    return User(
      id: fbUser.uid,
      name: fbUser.displayName ?? '',
      email: fbUser.email ?? '',
      profileImageUrl: fbUser.photoURL,
    );
  }

  // Register a new user
  Future<void> register({required String name, required String email, required String password}) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Update display name
      await credential.user?.updateDisplayName(name);

      _user = _firebaseUserToUser(credential.user!);
      notifyListeners();
    } on fb.FirebaseAuthException catch (e) {
      throw Exception(e.message);
    }
  }

  // Login
  Future<void> login({required String email, required String password}) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      _user = _firebaseUserToUser(credential.user!);
      notifyListeners();
    } on fb.FirebaseAuthException catch (e) {
      throw Exception(e.message);
    }
  }

  // Logout
  Future<void> logout() async {
    await _auth.signOut();
    _user = null;
    notifyListeners();
  }

  // Update profile (name and email)
  Future<void> updateProfile({String? name, String? email}) async {
    final currentUser = _auth.currentUser;
    if (currentUser != null) {
      if (name != null) {
        await currentUser.updateDisplayName(name);
        _user = _user!.copyWith(name: name);
      }
      if (email != null) {
        await currentUser.updateEmail(email);
        _user = _user!.copyWith(email: email);
      }
      notifyListeners();
    }
  }

  // Change password
Future<void> changePassword({
  required String currentPassword,
  required String newPassword,
}) async {
  final user = _auth.currentUser;
  if (user == null) throw Exception("No logged-in user");

  // Reauthenticate
  final cred = fb.EmailAuthProvider.credential(
    email: user.email!,
    password: currentPassword,
  );
  await user.reauthenticateWithCredential(cred);

  // Update password
  await user.updatePassword(newPassword);
}

}
