import 'package:flutter/material.dart';
import '../models/payment_method.dart';

class PaymentProvider with ChangeNotifier {
  final List<PaymentMethod> _methods = [
    PaymentMethod(type: 'Visa', details: '**** 1234', expiry: '12/25'),
    PaymentMethod(type: 'PayPal', details: 'john.doe@example.com'),
  ];

  List<PaymentMethod> get methods => _methods;

  void addMethod(PaymentMethod method) {
    _methods.add(method);
    notifyListeners();
  }

  void removeMethod(int index) {
    _methods.removeAt(index);
    notifyListeners();
  }
}
