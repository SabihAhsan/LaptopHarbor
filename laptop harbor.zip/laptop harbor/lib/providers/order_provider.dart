import 'package:flutter/foundation.dart';
import '../models/order.dart';
import '../models/order_status.dart'; // ✅ Shared enum with .color/.label/.icon
import '../models/product.dart';
import 'cart_provider.dart';

/// ================= ORDER PROVIDER =================
class OrderProvider extends ChangeNotifier {
  final List<Order> _orders = [];

  /// Unmodifiable list of orders
  List<Order> get orders => List.unmodifiable(_orders);

  /// Filter orders by status
  List<Order> getOrdersByStatus(OrderStatus status) =>
      _orders.where((o) => o.status == status).toList();

  /// All completed (delivered) orders
  List<Order> get completedOrders =>
      _orders.where((o) => o.status == OrderStatus.delivered).toList();

  /// Pending/Processing orders
  List<Order> get pendingOrders =>
      _orders.where((o) => o.status != OrderStatus.delivered).toList();

  /// Get single order by ID (nullable)
  Order? getOrderById(String id) {
    final index = _orders.indexWhere((o) => o.id == id);
    if (index == -1) return null; // ✅ Return null if not found
    return _orders[index];
  }

  /// ================= ADD NEW ORDER FROM CART =================
  void addOrderFromCart(
    CartProvider cart,
    String shippingAddress,
    String paymentMethod,
  ) {
    if (cart.items.isEmpty) return; // ignore empty cart

    final orderItems = cart.items.map((item) => OrderItem(
          productId: item.product.id,
          productName: item.product.name,
          productImage: item.product.imageUrl,
          productPrice: item.product.price,
          quantity: item.quantity,
        )).toList();

    final order = Order(
      id: "ORD-${DateTime.now().millisecondsSinceEpoch}",
      items: orderItems,
      totalAmount: cart.subtotal,
      orderDate: DateTime.now(),
      shippingAddress: shippingAddress,
      paymentMethod: paymentMethod,
      status: OrderStatus.processing,
    );

    _orders.insert(0, order);
    notifyListeners();
  }

  /// ================= UPDATE STATUS =================
  void updateOrderStatus(String orderId, OrderStatus newStatus) {
    final index = _orders.indexWhere((o) => o.id == orderId);
    if (index == -1) throw Exception("Order not found");

    _orders[index].updateStatus(newStatus);
    notifyListeners();
  }

  /// Quick helper shortcuts
  void markAsDelivered(String id) => updateOrderStatus(id, OrderStatus.delivered);
  void cancelOrder(String id) => updateOrderStatus(id, OrderStatus.cancelled);
  void markAsShipped(String id) => updateOrderStatus(id, OrderStatus.shipped);

  /// ================= REMOVE ORDER =================
  void deleteOrder(String id) {
    _orders.removeWhere((o) => o.id == id);
    notifyListeners();
  }

  /// ================= PERSISTENCE (Future Expandable) =================
  Future<void> saveOrders() async {
    final ordersJson = _orders.map((o) => o.toJson()).toList();
    if (kDebugMode) print("🟢 Orders Saved: $ordersJson");
    // TODO: implement actual storage (SharedPreferences/Hive)
  }

  Future<void> loadOrders() async {
    // TODO: implement load from local storage
    notifyListeners();
    if (kDebugMode) print("📥 Orders Loaded");
  }
}
