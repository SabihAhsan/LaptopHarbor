import 'package:flutter/material.dart';

class AppTheme {
  // ================= COLORS =================
  static const Color primaryMaroon = Color(0xFF800000);
  static const Color deepMaroon = Color(0xFF4D0000);
  static const Color lightMaroon = Color(0xFFA52A2A);
  static const Color accentGold = Color(0xFFD4AF37);

  static const Color lightScaffold = Color(0xFFFDF8F8);
  static const Color darkScaffold = Color(0xFF1A0000);

  static const Color lightCard = Colors.white;
  static const Color darkCard = Color(0xFF2D0000);

  static const Color lightText = Colors.black87;
  static const Color darkText = Colors.white;

  // ========== BACKWARD COMPATIBILITY ==========
  static const Color primaryColor = primaryMaroon;
  static const Color textColor = lightText;
  static const Color scaffoldColor = lightScaffold;

  // ================= LIGHT THEME =================
  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: lightScaffold,
    primaryColor: primaryMaroon,

    colorScheme: ColorScheme.fromSeed(
      seedColor: primaryMaroon,
      brightness: Brightness.light,
      primary: primaryMaroon,
      secondary: lightMaroon,
      tertiary: accentGold,
      surface: lightCard,
      error: const Color(0xFFB00020),
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onSurface: lightText,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor: primaryMaroon,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    ),

    cardTheme: CardThemeData(
      color: lightCard,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),

    textTheme: const TextTheme(
      headlineLarge:
          TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: deepMaroon),
      headlineMedium:
          TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: deepMaroon),
      titleLarge:
          TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: deepMaroon),
      bodyLarge: TextStyle(fontSize: 16, color: lightText),
      bodyMedium: TextStyle(fontSize: 14, color: Colors.black54),
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryMaroon,
        foregroundColor: Colors.white,
        minimumSize: const Size(double.infinity, 50),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    ),
  );

  // ================= DARK THEME =================
  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: darkScaffold,
    primaryColor: primaryMaroon,

    colorScheme: const ColorScheme.dark(
      primary: primaryMaroon,
      secondary: lightMaroon,
      tertiary: accentGold,
      surface: darkCard,
      error: Color(0xFFCF6679),
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onSurface: darkText,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor: deepMaroon,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    ),

    cardTheme: CardThemeData(
      color: darkCard,
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),

    textTheme: const TextTheme(
      headlineLarge:
          TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white),
      headlineMedium:
          TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
      titleLarge:
          TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Colors.white),
      bodyLarge: TextStyle(fontSize: 16, color: Colors.white70),
      bodyMedium: TextStyle(fontSize: 14, color: Colors.white60),
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryMaroon,
        foregroundColor: Colors.white,
        minimumSize: const Size(double.infinity, 50),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    ),
  );
}
